# Five Relics Color-Block Collage — Full Prompt

Use the user's five artifact photographs as the only sources for the objects. Create one vertical surreal collage. Return only the finished image; complete identification, composition, and color decisions internally without outputting analysis or prompt explanations.

## Inputs and source strip

Inspect all five photographs and identify each main object's shape, proportions, material, patterns, damage, pose, and colors. If one photo contains several artifacts, select one representative object or preserve a clearly related group.

At the absolute top of the canvas, place one continuous horizontal source strip made of exactly five equal square cells. Cells touch edge-to-edge with no gaps and no title. Each cell corresponds to one input photo, in order from left to right. Keep each cell in its original photographic color. Cropping and scaling to fit the square are allowed; do not desaturate, redraw, or replace the artifact. Keep each artifact as legible as possible at this small scale.

## Main scene below

The area below the source strip occupies most of the canvas. Remove display cases, plinths, labels, and unrelated surroundings from the source photographs. Translate the five artifacts into recognizable visual subjects. Choose the treatment for each artifact separately: retain authentic material color visible in its source photo, render it in monochrome or grayscale, or preserve color only in selected areas. Color and black-and-white artifacts may coexist. Use the difference to clarify hierarchy, material, and interaction; do not force all five into one treatment or arbitrarily recolor them with hues absent from their sources. Recompose the objects by changing their scale, angle, position, depth, and overlap.

Create a clear new relationship among the five objects. At least two artifacts from different source photographs must interact visibly: one might pass through a coin’s square hole, a vessel might receive another object, tower elements might nest with the stele, or contact and foreground occlusion might imply a continuous action. Let the relationship follow from their shapes, structures, and materials, while keeping each object recognizable. Floating, inversion, misalignment, repetition, and scale shifts may support that interaction. Do not arrange the five objects as a flat catalog or imply interaction only through background lines. Vary their heights, add modest tilts and selected floating elements, and lead the eye through an asymmetrical or curved rhythm with breathing room. Avoid the rigid solemnity of a museum display row.

## White or gold threads and decorative light trails

A few fine white or gold lines may connect the artifacts in the lower scene. They may be tangible threads passing through holes or around rims, or floating thread-like decorative light trails; not every line needs a physical anchor. Let them follow the visual movement between artifacts in graceful curves, with slight soft glow and front-to-back crossings where useful. Lines do not replace physical interaction between artifacts. Avoid dense webs, thick ropes, circuit-like glare, evenly radiating rays, or chaotic random strokes. Keep lines out of the top five source cells and off defining patterns.

## Original color blocks and composition

Use a vivid red-yellow-blue relationship for the background: saturated cobalt blue as the dominant field, vermilion or orange-red as a ground, horizontal band, or broad color plane, and bright mineral yellow as a distinct circular or geometric contrast shape. The colors may carry subtle pigment grain, paper, or print texture while retaining strong saturation and contrast. For this set of five artifacts, determine the areas, edges, shapes, positions, and layers of each color anew. Use arcs, geometric shapes, bands, broken fields, or irregular paper forms. The references guide only the color character; do not copy their artifact arrangements, color-block proportions, or exact compositions. Color blocks should establish hierarchy, depth, overlap, or rhythm rather than act as unrelated decoration.

Keep a clear visual center and considered negative space. The lower scene may use paper, mineral pigment, grain, aged print, or handmade collage textures while keeping the artifacts' contours and surface details legible. Avoid meaningless gradients, overly dense texture, and random fragments.

## Boundaries and output

- The five source photographs at the top remain in color; there must be exactly five square cells in one row at the top.
- Preserve the existing five-image source strip unchanged. Below it, keep a saturated cobalt-blue-dominant background with vermilion/orange-red and bright mineral-yellow accents; do not generalize this into an arbitrary palette.
- The references guide only the red-yellow-blue color direction, not artifact content, object relationships, or exact composition.
- Apply color, monochrome, or selective color only to the artifacts in the generated scene below; these treatments may coexist. The original source-photo cells always remain in color.
- At least one legible interaction must connect artifacts from two different source photographs. Make contact, passage, or occlusion readable without hiding their defining forms.
- A few white or gold lines may be tangible threads or floating decorative light trails. Individual artifact anchors are optional; keep the overall flow clear, fine, and lively.
- Preserve recognizable artifact forms, proportions, visible patterns, and damage. Do not invent text, inscriptions, dates, collection information, or archaeological facts.
- Add no unrelated artifacts, landmarks, or people. No phone interface, display case, plinth, screenshot border, title, letters, numbers, logo, or watermark.
- The canvas must be complete and opaque, defaulting to a vertical 2:3 ratio. Return only one final image, with no analysis, alternatives, or extra copy.
