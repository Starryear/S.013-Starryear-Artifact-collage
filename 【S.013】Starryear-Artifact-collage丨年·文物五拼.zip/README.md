<div align="center">

# 【S.013】Starryear-Artifact-collage丨年·文物五拼

**五张彩色文物原图在顶端并列，下方以浓郁红黄蓝背景构成器物拼贴。**

[![Codex Skill](https://img.shields.io/badge/Codex-Skill-000000?style=for-the-badge&logo=openai&logoColor=white)](#)
[![Usage](https://img.shields.io/badge/Usage-Personal%20%26%20Non--commercial-lightgrey?style=for-the-badge)](./LICENSE.md)
[![Language](https://img.shields.io/badge/🌐_中文-English-blue?style=for-the-badge)](#)

</div>

---

## ⚠️ 使用声明

> **仅限个人学习、非营利研究与非商业创作。** 任何商业使用均须事先取得 Starryear年 的书面许可。分享作品时欢迎标注来源并 **@Starryear年**。

## 📖 关于本项目

本 Skill 将五张文物照片组织成一张竖版拼贴。最顶端固定呈现五张彩色原图的小方格，下面以浓郁钴蓝为主背景，配朱红/橘红和明亮矿物黄构成鲜明对比；器物可分别保留真实材质彩色、转为黑白或局部保色；至少两件不同来源的文物发生可见互动，并以错落、倾斜和少量白色或金色丝线状光效串联画面，构成更轻快的超现实关系。

- ✅ 顶端固定五张彩色来源图，单排正方形排列。
- ✅ 下方主体可混合彩色与黑白处理；至少两件不同来源的器物发生可见互动，可用少量白色或金色细线或装饰光效串联，背景保持鲜明红黄蓝关系。
- ❌ 不用于文物鉴定、修复或严谨的历史场景复原。

完整提示词提供**中文**和**英文**版本。

## 🖼️ 示例作品

以下四张为本项目的展示图。实际生成时应根据当次输入的五张文物照片重新构图。

![参考图 1](assets/examples/example-1.png)
![参考图 2](assets/examples/example-2.png)
![参考图 3](assets/examples/example-3.png)
![参考图 4](assets/examples/example-4.png)

## 📋 目录

- [使用方法](#-使用方法)
- [可调整部分](#-可调整部分)
- [核心原则](#-核心原则)
- [内容结构](#-内容结构)
- [许可证](#-许可证)

## 🚀 使用方法

### 作为 Codex Skill

将 `five-relic-color-collage` 文件夹放入 Codex 的 skills 目录，上传五张文物照片并提出需求，例如：“使用 `five-relic-color-collage` 把这五张文物照片做成色块拼贴。”

### 直接使用提示词

| 语言 | 文件 |
| :---: | :--- |
| 中文 | [完整中文提示词](references/five-relic-color-collage-prompt.zh-CN.md) |
| English | [Full English prompt](references/five-relic-color-collage-prompt.en.md) |

## 🎛️ 可调整部分

| 参数 | 说明 |
| :--- | :--- |
| 画幅比例 | 默认竖版 2:3，可按发布场景调整；顶部仍保留五格单排。 |
| 下方色块 | 以钴蓝背景、朱红/橘红和矿物黄形成红黄蓝关系；形状、面积和位置随器物构图调整。 |
| 器物关系 | 至少两件不同来源的器物产生可见互动；可采用承托、穿越、嵌套、接触或遮挡等方式，并用错落高低与轻微倾斜增加流动感。 |
| 连接细线 | 可用少量白色或金色实体丝线或悬浮装饰光效；不要求每条线都连接器物。 |
| 生成主体风格 | 逐件选择真实材质彩色、黑白灰或局部保色；可混合使用，不能任意重染。 |

## 💡 核心原则

1. **原图在顶端保留彩色** — 五张照片各占一个等大的正方形来源格。
2. **彩色与黑白可同场互动** — 下方器物逐件决定色调，至少两件不同来源的器物建立可见关系。
3. **线条带出节奏** — 少量白色或金色实体丝线或装饰光效沿画面动势延伸，无须每条都附着器物。
4. **红黄蓝方向稳定，布局每次重构** — 保持钴蓝、朱红/橘红与矿物黄的浓郁关系，色块和器物关系从当次输入出发，不复刻参考图构图。

## 📁 内容结构

```text
five-relic-color-collage/
├── README.md
├── LICENSE.md
├── SKILL.md
├── agents/openai.yaml
├── references/
│   ├── five-relic-color-collage-prompt.zh-CN.md
│   └── five-relic-color-collage-prompt.en.md
└── assets/examples/
```

`assets/examples/` 收录以上四张成品参考图。

## 📄 许可证

本项目使用条款见 [LICENSE.md](./LICENSE.md)。

<div align="center">**欢迎 Star ⭐ 支持**</div>
